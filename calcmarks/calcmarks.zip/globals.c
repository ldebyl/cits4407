#include  "calcmarks.h"              // we use double-quotes

// calcmarks, version 1, released Fri May  8 11:20:00 AWST 2020

double    projmarks[ MAXMARKS ];     // array's size is defined
double    exammarks[ MAXMARKS ];     // array's size is defined

bool      verbose = false;           // global is initialized
